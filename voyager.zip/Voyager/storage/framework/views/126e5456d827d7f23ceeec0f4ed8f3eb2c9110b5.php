<?php echo $__env->make('voyager-frontend::partials.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('voyager-frontend::partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="main-content">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->make('voyager-frontend::partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/vhosts/jango.jan-it-solutions.com/httpdocs/Voyager/vendor/pvtl/voyager-frontend/src/Providers/../../resources/views/layouts/default.blade.php ENDPATH**/ ?>