You are welcome!
<?php /**PATH /var/www/vhosts/jango.jan-it-solutions.com/httpdocs/Voyager/resources/views/home.blade.php ENDPATH**/ ?>