<form id="search-form" action="/search" method="GET">
    <div class="input-group">
        <input class="input-group-field" name="keywords" type="search" value="<?php echo e(\Request::get('keywords')); ?>" placeholder="I'm looking for..."/>
        <div class="input-group-button">
            <input type="submit" class="button dark" value="Search">
        </div>
    </div>
</form><?php /**PATH /var/www/vhosts/jango.jan-it-solutions.com/httpdocs/Voyager/vendor/pvtl/voyager-frontend/src/Providers/../../resources/views/partials/search-box.blade.php ENDPATH**/ ?>