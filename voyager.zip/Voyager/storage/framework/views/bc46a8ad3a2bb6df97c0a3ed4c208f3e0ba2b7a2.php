<li class="hide-for-small-only"><a href="#" data-toggle-search-trigger><i class="fas fa-search"></i></a></li>

<?php if(Auth::guest()): ?>
    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
<?php endif; ?>

<?php if(!Auth::guest()): ?>
    <ul class="dropdown menu" data-dropdown-menu>
        <li>
            <a href="#">My Account</a>
            <ul class="menu">
                <li>
                    <a href="<?php echo e(route('voyager-frontend.account')); ?>">
                        Update Account
                    </a>

                    <?php if(Session::has('original_user.id')): ?>
                        <a href="#"
                           onclick="event.preventDefault();document.getElementById('impersonate-form').submit();">
                            Switch back to <?php echo e(Session::get('original_user.name')); ?>

                        </a>

                        <form id="impersonate-form"
                              action="<?php echo e(route('voyager-frontend.account.impersonate', Session::get('original_user.id'))); ?>"
                              method="POST"
                              style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    <?php else: ?>
                        <a href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                            Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    <?php endif; ?>
                </li>
            </ul> <!-- /.menu -->
        </li>
    </ul> <!-- /.dropdown -->
<?php endif; ?>
<?php /**PATH /var/www/vhosts/jango.jan-it-solutions.com/httpdocs/Voyager/vendor/pvtl/voyager-frontend/src/Providers/../../resources/views/partials/menu-right.blade.php ENDPATH**/ ?>